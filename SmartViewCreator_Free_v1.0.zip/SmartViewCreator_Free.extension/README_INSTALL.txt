Smart View Creator - Free Edition (v1.0)
==========================================

INSTALLATION
------------
1. Extract "SmartViewCreator_Free.extension" to your pyRevit extensions
   folder (e.g. %APPDATA%\pyRevit\Extensions\).
2. In Revit, go to pyRevit tab -> Settings -> Custom Extension
   Directories and ensure the path is added.
3. Reload pyRevit (Ctrl + Alt + R).

After reloading, you will find "Smart View Creator" on the
SmartView tab, in the Create panel.

WHAT'S INCLUDED
----------------
Batch-create Floor Plan / Ceiling Plan / Structural Plan views for
every selected level, with Prefix/Suffix naming and an optional View
Template - unlimited levels, no license key required.

Want automatic Sheet generation, Scope Box alignment and Dependent
Views (Zones)? Check out the Pro edition.
