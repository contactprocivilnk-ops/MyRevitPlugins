# -*- coding: utf-8 -*-
"""Smart View Creator - BIM Manager (Free edition) - V2.0.

WPF UI (ui.xaml): collects Levels / ViewFamilyTypes (Floor, Ceiling,
Structural) / View Templates from the active document and populates
the UI with them. "Create Views" creates one view per checked level -
Prefix/Suffix naming with safe collision handling and optional View
Template assignment - inside a single Transaction.

Feature-gated Free edition: no level limit - every checked level gets
a view, even if one of the same ViewFamilyType already exists (the
new view is given a guaranteed-unique name rather than being skipped).
No Sheets, Scope Boxes, Titleblocks or Dependent Views in this
edition - see the Pro edition for those.

Written for pyRevit on Revit 2020-2026 (CPython 3 and IronPython 2.7
engines).
"""

import re

import clr
clr.AddReference("PresentationFramework")
clr.AddReference("PresentationCore")
clr.AddReference("WindowsBase")

from System.Windows import Thickness, VerticalAlignment
from System.Windows.Controls import CheckBox, TextBlock, StackPanel, Orientation

from pyrevit import revit, DB, forms, script

doc = revit.doc
output = script.get_output()

try:
    _text_type = unicode  # noqa: F821 - IronPython 2.7
except NameError:
    _text_type = str  # CPython 3

PLAN_VIEW_FAMILIES = (
    DB.ViewFamily.FloorPlan,
    DB.ViewFamily.CeilingPlan,
    DB.ViewFamily.StructuralPlan,
)

# Characters Revit itself forbids in an element name, regardless of
# language/script. Everything else - including Arabic, CJK, Cyrillic,
# accented Latin, etc. - is left untouched by safe_str().
FORBIDDEN_REVIT_CHARS = set(r'\:{}[]|;<>?')


# ----------------------------------------------------------------------------
# Small helpers (self-contained - no dependency on other bundles)
# ----------------------------------------------------------------------------

def get_name(element):
    """Return an element's name safely across hosts.

    Element.Name is shadowed / unreliable for Level, View and
    ViewFamilyType under some engine + API version combinations, so the
    underlying parameter is read first and the Element.Name property is
    used only as a fallback.
    """
    if element is None:
        return "<none>"
    for bip in (DB.BuiltInParameter.VIEW_NAME,
                DB.BuiltInParameter.DATUM_TEXT,
                DB.BuiltInParameter.SYMBOL_NAME_PARAM):
        try:
            param = element.get_Parameter(bip)
            if param and param.AsString():
                return param.AsString()
        except Exception:
            pass
    try:
        return element.Name
    except Exception:
        return "<unnamed>"


def safe_str(val):
    """Return `val` as Revit-safe text: every Unicode letter/number
    (Arabic, CJK, Cyrillic, accented Latin, ...) is kept, and only the
    characters Revit itself forbids in an element name - plus emoji -
    are stripped. Emoji specifically are excluded because IronPython
    2.7's narrow string handling can raise ValueError ("X is not in
    required range") when a high-codepoint character reaches
    chr()/encode() elsewhere in the naming pipeline."""
    if not val:
        return ""
    cleaned = []
    for ch in _text_type(val):
        if ch in FORBIDDEN_REVIT_CHARS:
            continue
        code = ord(ch)
        # Common emoji blocks (pictographs, symbols), plus the UTF-16
        # surrogate range (0xD800-0xDFFF): IronPython 2.7 iterates
        # narrow UTF-16 strings one code UNIT at a time, so a
        # high-plane emoji (U+1F000-U+1FAFF) never shows up as a
        # single ord() in that range - it arrives as two surrogate
        # halves instead, which this check catches directly.
        if (0x1F000 <= code <= 0x1FAFF or 0x2600 <= code <= 0x27BF
                or 0xD800 <= code <= 0xDFFF):
            continue
        cleaned.append(ch)
    return "".join(cleaned).strip()


def safe_elevation(level):
    """Return a level's elevation in internal feet, or None if the level
    is corrupt / missing a readable Elevation."""
    try:
        elev = level.Elevation
    except Exception:
        return None
    if elev is None:
        return None
    try:
        if elev != elev or elev in (float("inf"), float("-inf")):
            return None
    except Exception:
        return None
    return float(elev)


def sort_levels_by_elevation(levels):
    """Return (sorted_valid_levels, skipped_levels) - sorted strictly by
    elevation (internal feet). Levels with an unreadable elevation are
    separated out rather than crashing the sort."""
    valid = []
    skipped = []
    for lvl in levels:
        elev = safe_elevation(lvl)
        if elev is None:
            skipped.append(lvl)
        else:
            valid.append((elev, lvl))
    valid.sort(key=lambda pair: pair[0])
    return [lvl for _, lvl in valid], skipped


def _is_template(view):
    try:
        return bool(view.IsTemplate)
    except Exception:
        return False


class NoneTemplateItem(object):
    """Lightweight stand-in for "no View Template", so the Template
    ComboBox can offer an explicit deselect option instead of forcing
    the user to pick a real template."""

    def __init__(self):
        self.Name = "<None>"
        self.Id = DB.ElementId.InvalidElementId


# ----------------------------------------------------------------------------
# Main window
# ----------------------------------------------------------------------------

class SmartViewCreatorWindow(forms.WPFWindow):

    def __init__(self, xaml_file_name):
        forms.WPFWindow.__init__(self, xaml_file_name)
        self._level_rows = []  # [{"checkbox", "level", "name"}]
        self._populate_ui()

    def _populate_ui(self):
        # 1. Populate Levels (levels_list) as checkbox rows, sorted by
        # elevation. The XAML ListView has no data-bound columns - each
        # row is a small CheckBox + TextBlock panel built here.
        self._populate_levels()

        # 2. Populate ViewFamilyTypes (Floor/Ceiling/Structural)
        self.view_types = [
            v for v in DB.FilteredElementCollector(doc).OfClass(DB.ViewFamilyType)
            if v.ViewFamily in PLAN_VIEW_FAMILIES
        ]
        self.view_type_combo.ItemsSource = self.view_types
        self.view_type_combo.DisplayMemberPath = "Name"
        if self.view_types:
            self.view_type_combo.SelectedIndex = 0

        # 3. Populate View Templates - "<None>" first so the user can
        # explicitly deselect a template rather than being forced to
        # pick a real one.
        self.templates = [NoneTemplateItem()] + [
            v for v in DB.FilteredElementCollector(doc).OfClass(DB.View).ToElements()
            if _is_template(v)
        ]
        self.template_combo.ItemsSource = self.templates
        self.template_combo.DisplayMemberPath = "Name"
        self.template_combo.SelectedIndex = 0

        # 4. Restore Prefix / Suffix from the previous session, if any
        # were saved.
        cfg = script.get_config()
        self.prefix_tb.Text = getattr(cfg, 'prefix', '')
        self.suffix_tb.Text = getattr(cfg, 'suffix', '')

        self._update_preview()

    def _populate_levels(self):
        levels = list(
            DB.FilteredElementCollector(doc)
            .OfCategory(DB.BuiltInCategory.OST_Levels)
            .WhereElementIsNotElementType()
            .ToElements()
        )
        sorted_levels, _skipped = sort_levels_by_elevation(levels)

        self.levels_list.Items.Clear()
        self._level_rows = []

        for level in sorted_levels:
            name = get_name(level)
            elevation = safe_elevation(level)
            elevation_text = (
                "{0:.3f} ft".format(elevation) if elevation is not None else "-")

            row = StackPanel()
            row.Orientation = Orientation.Horizontal
            row.Margin = Thickness(2, 3, 2, 3)

            checkbox = CheckBox()
            checkbox.IsChecked = True
            checkbox.VerticalAlignment = VerticalAlignment.Center
            checkbox.Margin = Thickness(0, 0, 8, 0)
            checkbox.Checked += self._on_level_checkbox_changed
            checkbox.Unchecked += self._on_level_checkbox_changed
            row.Children.Add(checkbox)

            label = TextBlock()
            label.Text = "{0}    (Elev: {1})".format(name, elevation_text)
            label.VerticalAlignment = VerticalAlignment.Center
            row.Children.Add(label)

            self.levels_list.Items.Add(row)
            self._level_rows.append({
                "checkbox": checkbox,
                "level": level,
                "name": name,
            })

        # Footer status line: live level counts.
        self.total_levels_tb.Text = "{0} levels available".format(len(self._level_rows))
        self._update_selected_count()

    def _on_level_checkbox_changed(self, sender, args):
        """Fires whenever a level checkbox is checked/unchecked, so the
        footer status line and Live Preview stay accurate."""
        self._update_selected_count()
        self._update_preview()

    def _update_selected_count(self):
        count = len(self._get_checked_levels())
        self.selected_levels_tb.Text = "{0} selected".format(count)

    def _get_checked_levels(self):
        """Return the (level, level_name) pairs whose checkbox is
        checked. levels_list holds checkbox rows built in code, not
        selectable bound items, so checked state can't be read from
        ListView.SelectedItems - it has to come from self._level_rows."""
        return [(row["level"], row["name"]) for row in self._level_rows
                if row["checkbox"].IsChecked]

    def _update_preview(self):
        """Refresh the "Preview: <prefix><level><suffix>" tag under the
        Naming Convention fields, using the first checked level's name
        (or the first level at all, or a placeholder if there are none)
        as the sample."""
        checked = self._get_checked_levels()
        if checked:
            sample_name = checked[0][1]
        elif self._level_rows:
            sample_name = self._level_rows[0]["name"]
        else:
            sample_name = "Level 1"

        prefix = safe_str(self.prefix_tb.Text or "")
        suffix = safe_str(self.suffix_tb.Text or "")
        self.preview_tb.Text = "{0}{1}{2}".format(prefix, safe_str(sample_name), suffix)

    # -- toolstrip: Select All / Select None / Invert --------------------

    def select_all(self, sender, args):
        for row in self._level_rows:
            row["checkbox"].IsChecked = True
        self._update_selected_count()
        self._update_preview()

    def select_none(self, sender, args):
        for row in self._level_rows:
            row["checkbox"].IsChecked = False
        self._update_selected_count()
        self._update_preview()

    def invert_selection(self, sender, args):
        for row in self._level_rows:
            row["checkbox"].IsChecked = not row["checkbox"].IsChecked
        self._update_selected_count()
        self._update_preview()

    # -- event handlers -------------------------------------------------

    def naming_changed(self, sender, args):
        self._update_preview()

    def cancel_click(self, sender, args):
        self.Close()

    def create_views(self, sender, args):
        prefix = safe_str(self.prefix_tb.Text or "")
        suffix = safe_str(self.suffix_tb.Text or "")
        selected_type = self.view_type_combo.SelectedItem
        selected_template = self.template_combo.SelectedItem

        # a) Levels checked in the UI.
        checked_levels = self._get_checked_levels()

        if not selected_type:
            forms.alert("Please select a view type to proceed.",
                        title="No View Type Selected", warn_icon=True)
            return

        if not checked_levels:
            forms.alert("Please select at least one level to proceed.",
                        title="No Levels Selected", warn_icon=True)
            return

        # The ComboBox's ItemsSource is bound directly to the
        # DB.ViewFamilyType elements, so SelectedItem already IS the
        # type - resolve its Id once, up front.
        vft_id = selected_type.Id

        used_names = set(
            get_name(v) for v in
            DB.FilteredElementCollector(doc).OfClass(DB.View).ToElements()
            if get_name(v))
        used_names_lower = set(name.lower() for name in used_names)

        def get_unique_view_name(base_name):
            """Return `base_name`, or `base_name (n)` for the first n
            not already taken. Revit view names collide case-
            insensitively ("Level 1" and "LEVEL 1" are the same name),
            so uniqueness is checked in lowercase. A level is never
            skipped just because a view with the same name already
            exists."""
            if base_name.lower() not in used_names_lower:
                return base_name
            counter = 1
            candidate = "{0} ({1})".format(base_name, counter)
            while candidate.lower() in used_names_lower:
                counter += 1
                candidate = "{0} ({1})".format(base_name, counter)
            return candidate

        created_count = 0
        failures = []

        try:
            # revit.Transaction() only calls Commit()/RollBack() on a
            # transaction it actually started, so a failure before or
            # during Start() can never trigger an invalid RollBack().
            with revit.Transaction("Create Smart Views"):
                for level, level_name in checked_levels:
                    try:
                        # 1. Create the ViewPlan - every checked level
                        # gets a view; none are dropped for already
                        # having one of the same type.
                        new_view = DB.ViewPlan.Create(doc, vft_id, level.Id)

                        # 2. Compute a guaranteed-unique name.
                        raw_name = "{0}{1}{2}".format(
                            prefix, safe_str(level_name), suffix).strip()
                        if not raw_name:
                            raw_name = safe_str(level_name) or "View"
                        final_name = get_unique_view_name(raw_name)
                        try:
                            new_view.Name = final_name
                        except Exception:
                            final_name = get_name(new_view)  # Handled safely
                        used_names.add(final_name)
                        used_names_lower.add(final_name.lower())

                        # 3. Apply View Template, if one is selected
                        # and still valid.
                        if (selected_template and hasattr(selected_template, 'Id')
                                and selected_template.Id != DB.ElementId.InvalidElementId):
                            try:
                                new_view.ViewTemplateId = selected_template.Id
                            except Exception:
                                pass  # Template assignment failed - view still created.

                        created_count += 1
                    except Exception as level_ex:
                        failures.append(level_name)
                        output.print_md(
                            "- Failed to create a view for level **{0}**: {1}".format(
                                level_name, str(level_ex)))

            # Save Prefix / Suffix so the next session starts with the
            # same settings.
            cfg = script.get_config()
            cfg.prefix = prefix
            cfg.suffix = suffix
            script.save_config()

            self.Close()

            if failures:
                output.print_md(
                    "## Created {0} view(s) - {1} level(s) failed, see above.".format(
                        created_count, len(failures)))
            else:
                output.print_md("## Success! Created {0} view(s).".format(created_count))
                output.print_md(
                    "Successfully created views for all selected levels! "
                    "*Want to automate Sheets, Scope Boxes, and Zone "
                    "generation? Check out the Pro edition!*")

            forms.alert(
                "Successfully created {0} view(s)!".format(created_count),
                title="Success")
        except Exception as e:
            forms.alert("Error creating views: {0}".format(str(e)),
                        title="Execution Error")


if __name__ == "__main__":
    if not doc or doc.IsFamilyDocument:
        forms.alert("Please open a valid project model (.rvt) to run this tool.",
                    title="No Active Project", warn_icon=True, exitscript=True)

    window = SmartViewCreatorWindow("ui.xaml")
    window.ShowDialog()
